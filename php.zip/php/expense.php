<?php
ini_set('display_errors', 1); error_reporting(-1);
//http://3.144.171.186/expense.php?exp_name=Groceries&exp_amt=200.00&budgetName=Jan+2022&frequency=weekly

$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "moneygo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    echo "Could not connect to database";
}

$exp_name=$_GET['exp_name'];
$exp_amt=$_GET['exp_amt'];
$frequency=$_GET['frequency'];
$budgetName=$_GET['budgetName'];
$inc_exp="expense";

/*
Frequency values
<option value="daily">Daily</option>        1
<option value="weekly">Weekly</option>      2
<option value="monthly">Monthly</option>    3
<option value="one">One Time</option>       4
*/
$freq=0; //initialize value
if ($frequency=="daily") {
    $freq=1;
}elseif ($frequency=="weekly") {
    $freq=2;
}elseif ($frequency=="monthly") {
    $freq=3;
}else{
    $freq=4;
}

$sql0 = "SELECT BudgetID FROM Budget  WHERE BudgetName = '$budgetName'";
echo "$budgetName <br>";
$result=$conn->query($sql0);
$row = mysqli_fetch_array($result);
$budget_id=$row['BudgetID'];


// Attempt insert query execution
$sql1 = "INSERT INTO Income_Expense (Name, Inc_Exp, Amount, Frequency, BudgetID) VALUES ('$exp_name', '$inc_exp', '$exp_amt', '$frequency', '$budget_id');";
$ans = " ";
if(mysqli_query($conn, $sql1)){
    $ans = "Expense $exp_name created successfully.";
} else{
    $ans = "ERROR: Could not able to execute $sql1. " . mysqli_error($conn);
}
echo "$ans";


$sql = "INSERT INTO `Income_Expense` WHERE ((`BudgetName` = '$budgetName'))";
                                    
$result = $conn->query($sql);
echo "$result";

$conn->close();

header("Location: budget.php?budgetName=$budgetName");


?>