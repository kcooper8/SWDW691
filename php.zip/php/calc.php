
        <?php 
        ini_set('display_errors', 1); error_reporting(-1);
        session_start();

        $servername = "localhost";
        $username = "root";
        $password = "password";
        $dbname = "moneygo";

        $budgetName=$_SESSION['BudgetName'];
        $entryName='None';
    
    
    
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
            echo "Connection to db unsuccessful ";
            }else{
            echo "Connected to db $dbname ";
            }



            //Here we create a loop to put the inc_exp names into a dropdown-style menu
        //Get the budget id
            $sql0 = "SELECT BudgetID FROM Budget  WHERE BudgetName = '$budgetName'";
        //echo "$budgetName <br>";
        $result=$conn->query($sql0);
        $row = mysqli_fetch_array($result);
        $budget_id=$row['BudgetID'];
                 
            $sql1 = "SELECT Amount FROM Income_Expense WHERE (BudgetID = $budget_id AND Inc_Exp = 'income' AND Frequency = 'monthly')";
                 
            $result = $conn->query($sql1);
            $monthly_amt=0;
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                
                while($row = $result->fetch_assoc()) {
                echo "<br> The amount of row is $row[Amount]";
                $monthly_amt=$monthly_amt+$row['Amount'];
                echo "<br> Monthly Amount: ($monthly_amt)";
                $rowCount ++; // increase the count
                echo "<br>Row count is: ($rowCount) <br> <br> <br>";
                }
                

            } else {
                echo "0 results";
            }

            $sql2 = "SELECT Amount FROM Income_Expense WHERE (BudgetID = $budget_id AND Inc_Exp = 'income' AND Frequency = 'weekly')";
                 
            $result = $conn->query($sql2);
            $weekly_amt=0;
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                
                while($row = $result->fetch_assoc()) {
                echo "<br> The amount of row is $row[Amount]";
                $weekly_amt=$weekly_amt+$row['Amount'];
                echo "<br> Weekly Amount: ($weekly_amt)";
                $rowCount ++; // increase the count
                echo "<br>Row count is: ($rowCount) <br> <br> <br>";
                }
                

            } else {
                echo "0 results";
            }

            $sql3 = "SELECT Amount FROM Income_Expense WHERE (BudgetID = $budget_id AND Inc_Exp = 'income' AND Frequency = 'daily')";
                 
            $result = $conn->query($sql3);
            $daily_amt=0;
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                
                while($row = $result->fetch_assoc()) {
                echo "<br> The amount of row is $row[Amount]";
                $daily_amt=$daily_amt+$row['Amount'];
                echo "<br> Daily Amount: ($daily_amt)";
                $rowCount ++; // increase the count
                echo "<br>Row count is: ($rowCount) <br> <br> <br>";
                }
                

            } else {
                echo "0 results";
            }

            $sql4 = "SELECT Amount FROM Income_Expense WHERE (BudgetID = $budget_id AND Inc_Exp = 'income' AND Frequency = 'one')";
                 
            $result = $conn->query($sql4);
            $one_amt=0;
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                
                while($row = $result->fetch_assoc()) {
                echo "<br> The amount of row is $row[Amount]";
                $one_amt=$one_amt+$row['Amount'];
                echo "<br> One time Amount: ($one_amt)";
                $rowCount ++; // increase the count
                echo "<br>Row count is: ($rowCount) <br> <br> <br>";
                }
                

            } else {
                echo "0 results";
            }

            $totalIncome=$monthly_amt+($weekly_amt*4)+($daily_amt*30)+$one_amt;
            echo "<br> Total income is: $totalIncome <br> <br> <br> <br>";

            $sql5 = "SELECT Amount FROM Income_Expense WHERE (BudgetID = $budget_id AND Inc_Exp = 'expense' AND Frequency = 'monthly')";
                 
            $result = $conn->query($sql5);
            $monthly_amtx=0;
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                
                while($row = $result->fetch_assoc()) {
                echo "<br> The amount of row is $row[Amount]";
                $monthly_amtx=$monthly_amtx+$row['Amount'];
                echo "<br> Monthly Amount: ($monthly_amtx)";
                $rowCount ++; // increase the count
                echo "<br>Row count is: ($rowCount) <br> <br> <br>";
                }
                

            } else {
                echo "0 results";
            }

            $sql6 = "SELECT Amount FROM Income_Expense WHERE (BudgetID = $budget_id AND Inc_Exp = 'expense' AND Frequency = 'weekly')";
                 
            $result = $conn->query($sql6);
            $weekly_amtx=0;
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                
                while($row = $result->fetch_assoc()) {
                echo "<br> The amount of row is $row[Amount]";
                $weekly_amtx=$weekly_amtx+$row['Amount'];
                echo "<br> Weekly Amount: ($weekly_amtx)";
                $rowCount ++; // increase the count
                echo "<br>Row count is: ($rowCount) <br> <br> <br>";
                }
                

            } else {
                echo "0 results";
            }

            $sql7 = "SELECT Amount FROM Income_Expense WHERE (BudgetID = $budget_id AND Inc_Exp = 'expense' AND Frequency = 'daily')";
                 
            $result = $conn->query($sql7);
            $daily_amtx=0;
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                
                while($row = $result->fetch_assoc()) {
                echo "<br> The amount of row is $row[Amount]";
                $daily_amtx=$daily_amtx+$row['Amount'];
                echo "<br> Daily Amount: ($daily_amtx)";
                $rowCount ++; // increase the count
                echo "<br>Row count is: ($rowCount) <br> <br> <br>";
                }
                

            } else {
                echo "0 results";
            }

            $sql8 = "SELECT Amount FROM Income_Expense WHERE (BudgetID = $budget_id AND Inc_Exp = 'expense' AND Frequency = 'one')";
                 
            $result = $conn->query($sql8);
            $one_amtx=0;
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                
                while($row = $result->fetch_assoc()) {
                echo "<br> The amount of row is $row[Amount]";
                $one_amtx=$one_amtx+$row['Amount'];
                echo "<br> One time Amount: ($one_amtx)";
                $rowCount ++; // increase the count
                echo "<br>Row count is: ($rowCount) <br> <br> <br>";
                }
                

            } else {
                echo "0 results";
            }

            $totalExpense=($monthly_amtx+($weekly_amtx*4)+($daily_amtx*30)+$one_amtx)*(-1);
            echo "<br> Total Expense is: $totalExpense <br> <br> <br> <br>";

            $surplus_deficit=($totalIncome+$totalExpense);
            echo "<br> Surplus/Deficit is: $surplus_deficit <br> <br> <br> <br>";

            $sql9="UPDATE Budget SET Surplus_Deficit=$surplus_deficit WHERE BudgetName='$budgetName';";

            $result=$conn->query($sql9);

            echo ($sql9);

            header("Location: budget.php?budgetName=$budgetName");
                  
        ?>

        
