<form>
    <select name="entryName" id="entryName">
        <?php 
        ini_set('display_errors', 1); error_reporting(-1);
        session_start();

        $servername = "localhost";
        $username = "root";
        $password = "password";
        $dbname = "moneygo";

        $budgetName=$_SESSION['BudgetName'];
        $entryName='None';
    
    
    
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
            echo "Connection to db unsuccessful ";
            }else{
            echo "Connected to db $dbname ";
            }

        if($_GET['entryName']!='None') {
                echo $_SESSION['entryName'];
        }
        else {
            $entryName = "Choose an Entry";
        }
        ?>
        <option selected="selected"><?php echo "$entryName" ?></option>
            <?php
            //Here we create a loop to put the inc_exp names into a dropdown-style menu
        //Get the budget id
            $sql0 = "SELECT BudgetID FROM Budget  WHERE BudgetName = '$budgetName'";
        //echo "$budgetName <br>";
        $result=$conn->query($sql0);
        $row = mysqli_fetch_array($result);
        $budget_id=$row['BudgetID'];
                 
            $sql1 = "SELECT Name FROM Income_Expense WHERE BudgetID = $budget_id";
                 
            $result = $conn->query($sql1);
                 
            if ($result->num_rows > 0) {
                // output data of each row
                $rowCount = 0; // set the count to 0 to initialize
                while($row = $result->fetch_assoc()) {
                echo "<option value='$row[Name]'>$row[Name]</option>";
                $rowCount ++; // increase the count
                }
            } else {
                echo "0 results";
            }
                  
        ?>
    </select>
    <input type="submit" value="Submit">
    <?php
        $entryName=$_GET['entryName'];
        if ($entryName) {
            echo "You have selected inc/exp $entryName";
            $_SESSION['EntryName']=$entryName;
        }else{
            echo "No inc/exp selected";
        }

    ?>

</form>

<h2>Delete Budget <?php echo "$entryName"; ?></h2>
<p>
    <a href="delete_entry.php?">Delete entry</a>
    <a href="budget.php?budgetName=<?php echo $budgetName ?>">Back to Budget</a>
</p>
