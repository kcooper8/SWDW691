<html>
    <?php
    session_start();

    $servername = "localhost";
    $username = "root";
    $password = "password";
    $dbname = "moneygo";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }


    ?>
    <head>
        <title>
            Where did the money go Budgeting
        </title>
        <link href="css/main.css" rel="stylesheet"/>
        <script src="app.php" type="application/javascript"></script>
       
    </head>

    <body>
        <header>
            <h1>Plan your budget</h1>
            <img src="img/moneygo.png">
    
        </header>

        <div id="leftsidebar">
            <h2>
                Site Navigation
            </h2>
            <ol id="orderedlist">
                
                <li> Budgeting</li>
                <li><a href="user_edit.php"> User Management </a></li>
            </ol>
        </div>
        <div id="maincontainer">
            <article>
                <h2>
                    Add a new budget
                </h2>
                <p id="budget">
                <?php 
                   if(!empty($_GET['message'])) {
                        $message = $_GET['message'];
                        echo $message; 
                   }
                   else {
                       echo "Please update your information.";
                   }
                ?>
                
            </p>
            <p id="create_budget">
                <form method="get" name="form" action="mod_bud.php"> 
                    <input type="text" placeholder="Enter email on record" name=emaillookup>
                    <input type="text" placeholder="Budget Name" name="bud_name">
                    <input type="submit" value="Create New Budget"> 
                </form>  
            
            </p>

            <h2>Select a Budget</h2>

            <p id="select_budget">

                
                    <form>
                        <select name="budgetName" id="budgetName">
                            <?php 
                            if(!empty($_GET['budgetName'])) {
                                    $budgetName = $_GET['budgetName'];
                            }
                            else {
                                $budgetName = "Choose a Budget";
                            }
                            ?>
                            <option selected="selected"><?php echo "$budgetName" ?></option>
                             <?php
                             //Here we create a loop to put the budget names into a dropdown-style menu
                             ini_set('display_errors', 1); error_reporting(-1);
                              $servername = "localhost";
                              $username = "root";
                              $password = "password";
                              $dbname = "moneygo";
                                      
                             // Create connection
                             $conn = new mysqli($servername, $username, $password, $dbname);
                             // Check connection
                             if ($conn->connect_error) {
                             die("Connection failed: " . $conn->connect_error);
                             echo "Connection to db unsuccessful <br>";
                             }else{
                             echo "Connected to db $dbname <br>";
                             
                             $sql = "SELECT BudgetName FROM Budget";
                             
                             $result = $conn->query($sql);
                             
                             if ($result->num_rows > 0) {
                                 // output data of each row
                                 $rowCount = 0; // set the count to 0 to initialize
                                 while($row = $result->fetch_assoc()) {
                                    echo "<option value='$row[BudgetName]'>$row[BudgetName]</option>";
                                   //echo "" . $row['BudgetName']. "<br>";
                                   $rowCount ++; // increase the count
                                 }
                               } else {
                                 echo "0 results";
                               }
                              }
                            ?>
                        </select>
                        <input type="submit" value="Submit">
                        <?php
                            $budgetName=$_GET['budgetName'];
                            if ($budgetName) {
                                echo "You have selected budget $budgetName";
                            }else{
                                echo "No budget selected";
                            }
                            $_SESSION['BudgetName']=$budgetName;
                        ?>

                    </form>
            </p>

            <h2>Delete Budget <?php echo "$budgetName"; ?></h2>
            <p>
                <a href="delete_budget.php?budgetname=<?php echo $budgetName; ?>">Delete budget</a>
            </p>


            <h2>Enter Expenses for Budget</h2>

            <p id="expenses">
                <?php 
                   if(!empty($_GET['message'])) {
                        $message = $_GET['message'];
                        echo $message; 
                   }
                   else {
                       echo " ";
                   }
                ?>
                
            </p>
                <form method="get" name="form" action="expense.php">
                    <input type="text" placeholder="Expense Name" name="exp_name">
                    <input type="text" placeholder="0.00" name="exp_amt">
                    <input type="text" value="<?php echo $budgetName; ?>" name="budgetName">
                    <label for="frequency">Expense Frequency</label>
                        <select name="frequency" id="frequency">
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                        <option value="one">One Time</option>
                        </select>
                    <input type="submit" value="Submit"> 
                </form>  
            
            </p>
            
            <h2>Enter Income for Budget</h2>
            <p id="income">
                <?php 
                   if(!empty($_GET['message'])) {
                        $message = $_GET['message'];
                        echo $message; 
                   }
                   else {
                       echo " ";
                   }
                ?>

            </p>
            <form method="get" name="form" action="income.php">
                    <input type="text" placeholder="Income Name" name="inc_name">
                    <input type="text" placeholder="0.00" name="inc_amt">
                    <input type="text" value="<?php echo $budgetName; ?>" name="budgetName">
                    <label for="frequency">Income Frequency</label>
                        <select name="frequency" id="frequency">
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                        <option value="one">One Time</option>
                        </select>
                    <input type="submit" value="Submit"> 
            
            </p>

            <h2>Select budget items for deletion</h2>
            <p><a href=form.php>Select Items for deletion</a></p>

            <h2>Calculate Surplus / Deficit for Budget</h2>
            <p>
            <?php
                $servername = "localhost";
                $username = "root";
                $password = "password";
                $dbname = "moneygo";
                        
               // Create connection
               $conn = new mysqli($servername, $username, $password, $dbname);
               // Check connection
               if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
                echo "Connection to db unsuccessful <br>";
               }else{
                //echo "Connected to db $dbname <br>";
               }

                $sql8 = "SELECT Surplus_Deficit FROM Budget WHERE BudgetName='$budgetName';";
                             
                $result = $conn->query($sql8);
                //echo "$budgetName <br>";
                //echo "$sql8";
                $row = mysqli_fetch_array($result);
                $surplus_deficit=$row['Surplus_Deficit'];
                
                if ($surplus_deficit>=0){
                        $surplus_deficit_which="Surplus";
                        $surplus_deficit_amt=$surplus_deficit;
                    }else if ($surplus_deficit<0){
                        $surplus_deficit_which="Deficit";
                        $surplus_deficit_amt=ABS($surplus_deficit);
                    }else{
                        $surplus_deficit_which="NULL";
                        $surplus_deficit_amt="NULL";
                    }
                    
            ?>
            <?php echo "You have a $surplus_deficit_which of $ $surplus_deficit_amt" ?>
            <a href=calc.php>Recalculate Surplus and Deficit Numbers</a>
            </p>

        </div>

        <footer>
            Copyright &copy; Where Did the Money Go 2021.  All rights reserved.
        </footer>
    </body>

</html>