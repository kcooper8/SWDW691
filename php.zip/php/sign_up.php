<html>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "password";
    $dbname = "moneygo";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

	/*
    // sql to create table
    $query="SELECT ID FROM MyGuests";
    $result = mysqli_query($dbConnection, $query);
    if(empty($result)) {
        $sql = "CREATE TABLE MyGuests (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        firstname VARCHAR(30) NOT NULL,
        lastname VARCHAR(30) NOT NULL,
        email VARCHAR(50),
        reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";

        if ($conn->query($sql) === TRUE) {
        echo "Table MyGuests created successfully";
        } else {
        echo "Error creating table: " . $conn->error;
        }

        $conn->close();

    }
    */

    ?>
    <head>
        <title>
            Where did the money go new user
        </title>
        <link href="css/main.css" rel="stylesheet"/>
        <script src="app.php" type="application/javascript"></script>
       
    </head>

    <body>
        <header>
            <h1>Please Sign Up</h1>
            <img src="img/moneygo.png">
    
        </header>

        <div id="leftsidebar">
            <h2>
                Site Navigation
            </h2>
            <ol id="orderedlist">
                <li><a href="manage.php"> Manage Accounts? </a></li>
                <li><a href="graphing.php"> Graphing </a></li>
                <li><a href="budget.php"> Budgeting </a></li>
                <li><a href="usermanage.php"> User Management </a></li>
            </ol>
        </div>
        <div id="maincontainer">
            <article>
                <h2>
                    Information Request
                </h2>
            <p id="loginMessage">
                <?php 
                   if(!empty($_GET['message'])) {
                        $message = $_GET['message'];
                        echo $message; 
                   }
                   else {
                       echo "Please enter your information so we can contact you.";
                   }
                ?>
                
            </p>
                <form method="get" name="form" action="data_enter.php"> 
                    <input type="text" placeholder="First Name" name="firstname">
                    <input type="text" placeholder="Last Name" name="lastname">
                    <input type="text" placeholder="Email Address" name="email">
					<input type="text" placeholder="Phone Number" name="phone">
                    <input type="text" placeholder="Password" name="password">
					<input type="text" placeholder="Security Question" name="secq">
					<input type="text" placeholder="Security Answer" name="secans">
                    <input type="submit" value="Submit"> 
                </form>  
            
            </p>
        </div>

        <footer>
            Copyright &copy; Society of St. Gregory Nazianzen 2020.  All rights reserved.
        </footer>
    </body>

</html>