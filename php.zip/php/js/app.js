var globalUser = "GU";
var globalPass = "PW";

function onLoad () {
    var userName = "user";
    var passWord = "1";
    var passCheck = "2";
    userName=prompt ("Create an account, please enter your username:");

    passWord=prompt ("Please create a password:"); 
    passCheck=prompt ("Please verify your password:");

    while (passWord != passCheck) {
        passWord=prompt ("Passwords do not match, please reeneter your password:");
        passCheck=prompt ("Please verify your password:");
    }

    globalUser=userName;
    globalPass=passWord;
}

function loginSubmit () {
    var subUser=document.getElementById ("UN").value;
    var subPass=document.getElementById ("PW").value;
    var theMessage= " "

    if ( (subUser==globalUser) && (subPass==globalPass) ) {
        theMessage =("Logged in as " + globalUser);
    }

    if ( (subUser==globalUser) && (subPass!=globalPass) ){
        theMessage ="Password Incorrect";
    }

    if (subUser!=globalUser) {
        theMessage =("No such user " + subUser);
    }
    document.getElementById ("loginMessage").innerHTML=theMessage;
}