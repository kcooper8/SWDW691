
<?php 

ini_set('display_errors', 1); error_reporting(-1);

/*
<input type="text" placeholder="Enter email on record" name=emaillookup>
<input type="text" placeholder="Budget Name" name="name">
<input type="submit" value="Create New Budget">
*/
    $emaillookup = $_GET['emaillookup'];
    $bud_name = $_GET['bud_name']; 

    $servername = "localhost";
    $username = "root";
    $password = "password";
    $dbname = "moneygo";



    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        echo "Connection to db unsuccessful ";
        }else{
        echo "Connected to db $dbname ";
        }
    
    $sql0 = "SELECT UserID FROM Users  WHERE email = '$emaillookup'";
    echo "$emaillookup";
    $result=$conn->query($sql0);
    $row = mysqli_fetch_array($result);
    $user_id=$row[UserID];
    //$user_id = $conn->query($sql0);
    

    
    // Attempt insert query execution
    $sql1 = "INSERT INTO Budget (BudgetName, UserID) VALUES ('$bud_name', '$user_id');";
    $ans = " ";
    if(mysqli_query($conn, $sql1)){
        $ans = "Budget $name created successfully.";
    } else{
        $ans = "ERROR: Could not able to execute $sql1. " . mysqli_error($link);
    }
    



    // Close connection
    mysqli_close($conn);

    //header ("Location: budget.php?message= $user_id");

    header ("Location: budget.php?message= $ans");
    //header("Location: sign_in.php?message=Budget $name Created");


    

?>