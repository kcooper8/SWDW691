<html>
<p id="select_budget">

                
<form>
    <select name="budgetName" id="budgetName">
        <option selected="selected">Choose one</option>
         <?php
         ini_set('display_errors', 1); error_reporting(-1);
          $servername = "localhost";
          $username = "root";
          $password = "password";
          $dbname = "moneygo";
                  
         // Create connection
         $conn = new mysqli($servername, $username, $password, $dbname);
         // Check connection
         if ($conn->connect_error) {
         die("Connection failed: " . $conn->connect_error);
         echo "Connection to db unsuccessful <br>";
         }else{
         echo "Connected to db $dbname <br>";
         
         $sql = "SELECT BudgetName FROM Budget";
         
         $result = $conn->query($sql);
         
         if ($result->num_rows > 0) {
             // output data of each row
             $rowCount = 0; // set the count to 0 to initialize
             while($row = $result->fetch_assoc()) {
                echo "<option value='($row[BudgetName])'>$row[BudgetName]</option>";
               //echo "" . $row['BudgetName']. "<br>";
               $rowCount ++; // increase the count
             }
           } else {
             echo "0 results";
           }
          }
             
        /*
        foreach($data as $item){
            echo "<option value='strtolower($item)'>$item</option>";
        }
        */
        ?>
    </select>
    <input type="submit" value="Submit">
    <?php
        $budgetName=$_GET['budgetName'];
        if ($budgetName) {
            echo "You have selected budget $budgetName";
        }else{
            echo "No budget selected";
        }
    ?>
    
</form>
</p>
</html>