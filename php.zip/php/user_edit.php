<html>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "password";
    $dbname = "moneygo";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

	/*
    // sql to create table
    $query="SELECT ID FROM MyGuests";
    $result = mysqli_query($dbConnection, $query);
    if(empty($result)) {
        $sql = "CREATE TABLE MyGuests (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        firstname VARCHAR(30) NOT NULL,
        lastname VARCHAR(30) NOT NULL,
        email VARCHAR(50),
        reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";

        if ($conn->query($sql) === TRUE) {
        echo "Table MyGuests created successfully";
        } else {
        echo "Error creating table: " . $conn->error;
        }

        $conn->close();

    }
    */

    ?>
    <head>
        <title>
            Where did the money go update user
        </title>
        <link href="css/main.css" rel="stylesheet"/>
        <script src="app.php" type="application/javascript"></script>
       
    </head>

    <body>
        <header>
            <h1>Please Update Account Information</h1>
            <img src="img/moneygo.png">
    
        </header>

        <div id="leftsidebar">
            <h2>
                Site Navigation
            </h2>
            <ol id="orderedlist">
                <li><a href="budget.php"> Budgeting </a></li>
                <li>User Management</li>
            </ol>
        </div>
        <div id="maincontainer">
            <article>
                <h2>
                    Information Update Form
                </h2>
            <p id="loginMessage">
                <?php 
                   if(!empty($_GET['message'])) {
                        $message = $_GET['message'];
                        echo $message; 
                   }
                   else {
                       echo "Please update your information.";
                   }
                ?>
                
            </p>
                <form method="get" name="form" action="data_mod.php"> 
                    <input type="text" placeholder="Enter email on record" name=emaillookup>
                    <input type="text" placeholder="First Name" name="firstname">
                    <input type="text" placeholder="Last Name" name="lastname">
                    <input type="text" placeholder="Email Address" name="email">
					<input type="text" placeholder="Phone Number" name="phone">
                    <input type="text" placeholder="Password" name="password">
					<input type="text" placeholder="Security Question" name="secq">
					<input type="text" placeholder="Security Answer" name="secans">
                    <input type="submit" value="Submit"> 
                </form>  
            
            </p>
        </div>

        <footer>
            Copyright &copy; Where Did the Money Go 2021.  All rights reserved.
        </footer>
    </body>

</html>