<?php
?>
<html>
    
    <head>
        <title>
            Where did the money go login
        </title>
        <link href="css/main.css" rel="stylesheet"/>
        <script src="app.php" type="application/javascript"></script>
       
    </head>

    <body>
        <header>
            <h1>Log in to where did the money go</h1>
            <img src="img/moneygo.png">
    
        </header>

        <div id="leftsidebar">
            <h2>
                Site Navigation
            </h2>
            <ol id="orderedlist">
            <li>Home</li>
                <li><a href="manage.php"> Manage Accounts? </a></li>
                <li><a href="graphing.php"> Graphing </a></li>
                <li><a href="budget.php"> Budgeting </a></li>
                <li><a href="usermanage.php"> User Management </a></li>
            </ol>
        </div>
        <div id="maincontainer">
            <article>
                <h2>
                    Please sign in
                </h2>
            <p id="loginMessage">
                <?php 
                   if(!empty($_GET['message'])) {
                        $message = $_GET['message'];
                        echo $message; 
                   }
                   else {
                       echo "Sign in here";
                   }
                ?>
                
            </p>
			<p id="sign up link">
				<a href="sign_up.php"> Not a User? Sign up here </a> 
			</p>
                <form method="get" name="form" action="login.php"> 
                    <input type="text" placeholder="Username" name="username">
                    <input type="password" placeholder="Password" name="password"> 
                    <input type="submit" value="Submit"> 
                </form>  
            
            </p>
        </div>

        <footer>
            Copyright &copy; Where Did the Money Go 2021.  All rights reserved.
        </footer>
    </body>

</html>