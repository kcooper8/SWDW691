
<?php 
    $firstname = $_GET['firstname']; 
    $lastname = $_GET['lastname'];
    $email = $_GET['email'];
    $phone = $_GET['phone'];
    $password = $_GET['password'];
    $secq = $_GET['secq'];
    $secans = $_GET['secans'];



    /* Attempt MySQL server connection. Assuming you are running MySQL
    server with default setting (user 'root' with no password) */
    $link = mysqli_connect("localhost", "root", "password", "moneygo");

    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Attempt insert query execution
    $sql = "INSERT INTO Users (Username, FirstName, LastName, email, Phone, password, sec_quest, sec_ans) VALUES ('$email', '$firstname', '$lastname', '$email', '$phone', '$password', '$secq', '$secans')";
    $ans = " ";
    if(mysqli_query($link, $sql)){
        $ans = "Records inserted successfully.";
    } else{
        $ans = "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }



    // Close connection
    mysqli_close($link);

    header ("Location: sign_in.php?message= $ans")
    //header("Location: sign_in.php?message=Thank you for submitting your information $firstname $lastname");

    

?>