<?php
ini_set('display_errors', 1); error_reporting(-1);

$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "moneygo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

$budgetName=$_GET['budgetName'];


$sql = "DELETE FROM `Budget` WHERE ((`BudgetName` = '$budgetName'))";
                                    
$result = $conn->query($sql);
echo "$result";

$conn->close();

header("Location: budget.php");


?>