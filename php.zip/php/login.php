<?php
$usernamev = $_GET['username']; 
$passwordv = $_GET['password'];

$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "moneygo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM Users  WHERE Username = '$usernamev' AND password = '$passwordv'";
echo "$username";
//$sql = "SELECT * FROM users WHERE Username=$username & Password=$password";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  $rowCount = 0; // set the count to 0 to initialize
  while($row = $result->fetch_assoc()) {
    echo "id: Username: " . $row[Username]. " " . $row[Password]. "<br>";
    $rowCount ++; // increase the count
  }
} else {
  echo "0 results";
}
$conn->close();

if ($rowCount > 0) {
    //header("Location: sign_in.php?message=Thank you for signing in $usernamev");
	header("Location: index.php");
}
else {
    header("Location: sign_in.php?message=Login not allowed");
}

/* 
    $username = $_GET['username']; 
    $password = $_GET['password'];


       Attempt MySQL server connection. Assuming you are running MySQL
    server with default setting (user 'root' with password 'password') 
    $link = mysqli_connect("localhost", "root", "password", "membership");


        // Attempt query execution
        $sql = "SELECT * FROM `users` WHERE Username = '$username' && Password = '$password'";
        if(mysqli_($link, $sql)){
            echo "Records retrieved successfully.";
        } else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
        }

        $rowcount=mysqli_num_rows($result);

        if($rowcount > 0){
            echo "$username successfully logged in";
        }
        else{
            echo "Login not successful";
        }


    // Close connection
    mysqli_close($link);

    //header("Location: sign_in.php?message=Thank you for submitting your information $firstname $lastname");

*/
?>