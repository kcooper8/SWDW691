<?php
ini_set('display_errors', 1); error_reporting(-1);
 $servername = "localhost";
 $username = "root";
 $password = "password";
 $dbname = "moneygo";
         
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
echo "Connection to db unsuccessful <br>";
}else{
echo "Connected to db $dbname <br>";

$sql = "SELECT BudgetName FROM Budget";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    $rowCount = 0; // set the count to 0 to initialize
    while($row = $result->fetch_assoc()) {
      echo "" . $row['BudgetName']. "<br>";
      $rowCount ++; // increase the count
    }
  } else {
    echo "0 results";
  }
 }
    
/*
$sql = "SELECT BudgetName FROM Budget";
$result = mysqli_query($conn, $sql);
$data = mysqli_fetch_array($result, MYSQLi_NUM);
/*         
$i = 0;
while (($row = mysqli_fetch_array($result, MYSQL_NUM)) !== false) {
$data[$i] = array_merge($data[$i], $row); 
$i++;
}
*/
                            
//print_r($row);
/*
// Iterating through the  array
foreach($data as $item){
echo "<option value='($item)'>$item</option>";
}
*/
?>