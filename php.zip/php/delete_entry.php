<?php
ini_set('display_errors', 1); error_reporting(-1);

session_start();

$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "moneygo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

$Name=$_SESSION['EntryName'];
$BudgetName=$_SESSION['BudgetName'];
echo "Entry Name: $Name <br> Budget Name: $BudgetName <br> ";

/*
$sql0 = "SELECT BudgetID FROM Income_Expense  WHERE Name = '$Name'";
$result0=$conn->query($sql0);
$row0 = mysqli_fetch_array($result0);
$BudgetID=$row0[BudgetID];
*/



$sql2 = "DELETE FROM `Income_Expense` WHERE ((`Name` = '$Name'))";                      
$result2 = $conn->query($sql2);
echo "$result2";
$conn->close();

header("Location: form.php?budgetName=$BudgetName");


?>