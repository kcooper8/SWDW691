<?php

print '
<!DOCTYPE html>
<!--this is a comment-->
<html>
    <head>
        <title>
            Where Did the Money Go?
        </title>
        <link href="css/main.css" rel="stylesheet"/>
       
    </head>

    <body>
        <header>
            <h1>Where Did the Money Go?</h1>
            <img src="img/moneygo.png">
        </header>

        <div id="leftsidebar">
            <h2>
                Site Navigation
            </h2>
            <ol id="orderedlist">
                <li>Home</li>
                <li><a href="budget.php"> Budgeting </a></li>
                <li><a href="user_edit.php"> User Management </a></li>
            </ol>
        </div>
        <div id="maincontainer">
            <article>
                <h2>
                    Manage your money
                </h2>
                <p>
                   This application will help you budget and track your investments
                </p>
            </article>

            <article>
                <h2>
                    Track your money
                </h2>
                <p>
                    <ul id="projects">
                        <li>
                            Set up your investment accounts to auto update with us.
                        </li>
                        <li>
                            Set up your regular and one time income and outgo.
                        </li>
                        <li>
                            Graph your progress!
                        </li>
                    </ul>
                </p>
            </article>
        </div>

        <footer>
            Copyright &copy; Where Did the Money Go 2021.  All rights reserved.
        </footer>
    </body>
    ';
   ?>
