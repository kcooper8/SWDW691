
<?php 
    $emaillookup = $_GET['emaillookup'];
    $firstname = $_GET['firstname']; 
    $lastname = $_GET['lastname'];
    $email = $_GET['email'];
    $phone = $_GET['phone'];
    $password = $_GET['password'];
    $secq = $_GET['secq'];
    $secans = $_GET['secans'];



    /* Attempt MySQL server connection. Assuming you are running MySQL
    server with default setting (user 'root' with no password) */
    $link = mysqli_connect("localhost", "root", "password", "moneygo");

    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Attempt insert query execution
    $sql = "UPDATE Users SET FirstName='$firstname' WHERE (email='$emaillookup');
            UPDATE Users SET LastName='$lastname' WHERE (email='$emaillookup');
            UPDATE Users SET Phone='$phone' WHERE (email='$emaillookup');
            UPDATE Users SET password='$password' WHERE (email='$emaillookup');
            UPDATE Users SET sec_quest='$secq' WHERE (email='$emaillookup');
            UPDATE Users SET sec_ans='$secans' WHERE (email='$emaillookup');
            UPDATE Users SET Username='$email' WHERE (email='$emaillookup');
            UPDATE Users SET email='$email' WHERE (email='$emaillookup');";
    $ans = " ";
    if(mysqli_multi_query($link, $sql)){
        $ans = "Records updated successfully.";
    } else{
        $ans = "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }



    // Close connection
    mysqli_close($link);

    header ("Location: user_edit.php?message= $ans")
    //header("Location: sign_in.php?message=Thank you for submitting your information $firstname $lastname");

    

?>