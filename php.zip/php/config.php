<?php
$host_name = "localhost";
$database = "moneygo"; // name of the database for this application
$username = "root";          // using the root user of the MySQL account
$password = "password";          // The password is password

//////// Do not Edit below /////////
try {
$dbo = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
} catch (PDOException $e) {
print "Error!: " . $e->getMessage() . "<br/>";
die();
}
?>